export interface Note  {
    id?: number;
    title: string;
    text: string;
    date: string;
    type: string;
    favorite: boolean;
}